@extends('layouts.blank')

@section('content')
	<div>
		
	</div>
@endsection